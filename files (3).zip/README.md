# CHIPS:// PRISMIRROR

This is the full source deployment of the CHIPS:// protocol and PRISMIRROR browser.

## Usage

- Launch the Electron app (`main.js`) to register the `chips://` protocol handler on your system.
- Use the PRISMIRROR Terminal UI (`index.html`) or the mobile terminal (`App.js`).
- Access a domain/context using the UI, or try an example link:  
  [chips://core.redmelon/root.Δ001](chips://core.redmelon/root.Δ001)  
  (Requires protocol handler registration.)

## Components

- **PRISMIRROR Terminal**: Cross-platform UI for contradiction-driven cognition.
- **Philosopher Orb**: Tap the orb for today’s contradiction, reflection, and dream echo.
- **chips-daemon**: (WIP) Node backend for custom protocol resolution.

## Work In Progress

Some files in `client/` and `server/` are placeholders for future expansion:
- `client/dream-archive.jsx`
- `client/prismirror-browser.jsx`
- `server/chips-daemon.js`

---

## Consistency

- All UIs use the button label **Access** and the placeholder **Enter domain/context (e.g., core.redmelon/root.Δ001)** for a unified experience.
- The protocol handler, UI, and documentation use the naming "CHIPS:// PRISMIRROR".